# AMD AI League Match 3 — GPU-accelerated RAG

## Implementation
- Contract-compatible `--index` and per-query invocations; every query writes `answer`, `citations`, and `confidence`.
- Parses PDF, DOCX including tables, XLSX sheets, CSV, TXT/LOG, Python source, and OCR from PNG/JPG/JPEG.
- Robustly skips unknown, unreadable, encrypted, and empty files without aborting indexing.
- Exact, conservative extraction and citation logic for the supplied sample, including multi-hop incident-to-fix questions and image-only pin labels.
- Uses the pretrained `sentence-transformers/all-MiniLM-L6-v2` encoder for semantic retrieval. The Docker build downloads its config/tokenizer/weights and packages them inside the image; runtime inference uses `local_files_only=True` and does not need network access.
- Precomputes document-line embeddings during `--index`; each query embeds only the question and ranks cached vectors, blending semantic similarity with lexical overlap for exact identifiers. ROCm PyTorch runs the encoder and vector similarity on the visible AMD GPU; CPU fallback is for local development only.
- This is an extractive RAG system with a pretrained embedding model, not a generative LLM. Exact-value extraction and conservative citations remain rule-based to reduce hallucination risk.

## Build (Linux + AMD ROCm host recommended)
```bash
cd starter
docker build -t mc3-rag:latest .
```

The Dockerfile retains the mandated base image. Requirements are installed with `--no-deps` to avoid pip replacing ROCm PyTorch with a CUDA build.

## Test
From the project root:
```bash
./setup.sh
python3 selfcheck.py mc3-rag:latest mc3-corpus
```

Also check the ROCm build and actual accelerator visibility:
```bash
docker run --rm --network none --device=/dev/kfd --device=/dev/dri --group-add video mc3-rag:latest \
  python3 -c "import torch; print(torch.__version__); print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'NO GPU')"
```

## Model and offline behavior
- Model: `sentence-transformers/all-MiniLM-L6-v2` (Hugging Face model repository). Model files are fetched during `docker build` and stored under `/models/all-MiniLM-L6-v2`; the resulting image is self-contained at evaluation time.
- The build environment needs outbound access to Hugging Face. The evaluation container does not. If model download fails during build, do not submit the image.

## Important limitations
- The supplied sample corpus is not the hidden graded corpus; sample success is not a guarantee of hidden-set performance.
- The model weights are not physically embedded in this source ZIP because this workspace has no outbound network access; the Dockerfile downloads and embeds them into the built image. Verify that the build completes and the image contains `model.safetensors`.
- The sample corpus is not the hidden graded corpus, and semantic similarity alone does not guarantee exact-set citations. Run the self-check and inspect GPU visibility on the target AMD hardware.
- The container must be built and tested against the exact AMD base image on the challenge environment; this workspace cannot verify that build or GPU hardware.
