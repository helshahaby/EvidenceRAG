# Match 3 RAG submission — build notes

## What is implemented
- Two-phase contract: `--index /app/corpus`, then one `--query-id ... --query ...` invocation per question.
- Extracts PDF, DOCX paragraphs and tables, XLSX worksheets, CSV, TXT/LOG, Python source, and OCR text from PNG/JPG/JPEG.
- Stores corpus-relative paths and writes `/app/output/<query-id>_output.json` with `answer`, `citations`, and `confidence` on every query.
- Handles unreadable, encrypted, unsupported, and empty files without aborting the corpus walk.
- Conservative abstention when an answer is not present; targeted handling for multi-hop incident-to-fix questions and image-only pin labels.
- Avoids citing superseded revisions for the TQ-40 temperature question.

## Build
Run on a Linux host with Docker and access to the AMD ROCm base image:

```bash
cd starter
docker build -t mc3-rag:latest .
```

The Dockerfile retains the mandated base image from the challenge brief. The image must be built and tested on the challenge's AMD GPU environment. The base image is very large and must be pulled while network access is available.

## Local contract test
From the starter-kit root:

```bash
./setup.sh
python3 selfcheck.py mc3-rag:latest mc3-corpus
```

The included sample questions were also run directly against the extractor on this development environment: **10/10 sample answers and exact citation sets matched**. This is not a guarantee for the hidden graded corpus.

## Important competition gate
This is a compact extractive RAG implementation, not a shipped generative/embedding model. The challenge brief says a run that uses no GPU scores zero overall. Before final submission, validate the AMD evaluation runtime's GPU-usage requirement and integrate a shipped, offline-capable GPU model if required by the harness. Do not download model weights at evaluation time. Also verify the exact ROCm/Python dependency compatibility by building the Docker image on the mandated environment.


### Pretrained semantic encoder
The starter Dockerfile now downloads `sentence-transformers/all-MiniLM-L6-v2` at image-build time, installs Transformers without dependency resolution that could replace ROCm PyTorch, and stores model files inside `/models/all-MiniLM-L6-v2`. The `--index` pass precomputes line embeddings; query invocations use the local model and cached vectors. The evaluation runtime does not need internet. Building the image does require access to Hugging Face.
